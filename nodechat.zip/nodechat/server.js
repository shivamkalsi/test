var express=require('express');
var app=express();
var bodyParser=require('body-parser');
var http=require('http').Server(app);
var path=require('path');
var io=require('socket.io')(http);


const PORT=process.env.PORT||3000;


/*app.use( function(req,res,next){
	if(req.header('x-forwarded-proto')=='http')
	{
		next();
	}
	else{
		res.redirect('http://'+req.hostname+req.url);
	}
});
*/
app.set('views', path.join(__dirname, 'views'));

app.set('view engine', 'jade');
app.use(express.static('public'));
app.use(bodyParser.urlencoded({extended:true}));
app.use(bodyParser.json());
app.get('/', function(req, res, next)
{
			res.render('home', {title:'Start Page'});
}
);

app.post('/', function(req, res, next)
{
	console.log(req.body.name);
	//console.log(res.params);
	res.render('index', {title:'Chat Page', username:req.body.name});
}
);






var server=http.listen(process.env.PORT || 3000, process.env.IP || "0.0.0.0", function(){
  var addr = server.address();
  console.log("Chat server listening at", addr.address + ":" + addr.port);
});


io.sockets.on('connection', function(socket){
	socket.on('send message', function(data){
		io.socket.emit('new message',{msg:data});
	});
});
